package sftp.bean;


import java.util.List;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/**
 * 
 * @author GS-2145
 * @class SFTPBean
 */

public class SFTPBean {
	
	// variable for sftp channel
	private JSch mJschSession = null;
	private Session mSSHSession = null;
	
	// sftp channel
	private ChannelSftp mChannelSftp = null;
	
	// connect function let connect to sftp server
	public boolean connect(String strHostAddress, int iPort, String strUserName, String strPassword) {
		boolean blResult = false;
		
		try {
			// creating a new jsch session
			this.mJschSession = new JSch();
			// set sftp server no check key when login
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			this.mJschSession.setConfig(config);
			// creating session with user, host port
			this.mSSHSession = mJschSession.getSession(strUserName, strHostAddress, iPort);
			// set password
			this.mSSHSession.setPassword(strPassword);
			// connect to host
			this.mSSHSession.connect();
			// open sftp channel
			this.mChannelSftp = (ChannelSftp) this.mSSHSession.openChannel("sftp");
			// connect to sftp session
			this.mChannelSftp.connect();
			if(this.mChannelSftp !=  null) {
				blResult = true;
			}
		}catch (Exception exp) {
			exp.printStackTrace();
		}
		return blResult;		
	}
	
	/**
	 * list of the file processed on sftp server
	 * @param strPath
	 * @return
	 */
	public List<LsEntry> listFile(String strPath){
		List<LsEntry> vtFile = null;
		
		try {
			vtFile = this.mChannelSftp.ls(strPath);
		}catch (Exception exp) {
			exp.printStackTrace();
		}
		return vtFile;
	}
	
	/**
	 * downloading file from strSftpFile remote sftp server location to strLocalFile location
	 * @param strSftpFile
	 * @param strLocalFile
	 * @return
	 */
	public boolean downloadFile(String strSftpFile, String strLocalFile) {
		boolean blResult = false;
		
		try {
			this.mChannelSftp.get(strSftpFile, strLocalFile);
			blResult = true;
		}catch (Exception exp) {
			exp.printStackTrace();
		}
		return blResult;
	}
	
	/**
	 * uploading file from strLocalFile location to strSftpFile remote sftp server location
	 * @param strLocalFile
	 * @param strSftpFile
	 * @return
	 */
	public boolean uploadFile(String strLocalFile, String strSftpFile) {
		boolean blResult = false;
		
		try {
			this.mChannelSftp.put(strLocalFile, strSftpFile);
			blResult = true;
		}catch (Exception exp) {
			exp.printStackTrace();
		}
		return blResult;
	}
	
	/**
	 * closing the sftp channel
	 */
	public void close() {
		try {
			this.mChannelSftp.disconnect();
		}catch (Exception exp) {
			
		}
		
		try {
			this.mSSHSession.disconnect();
		}catch (Exception exp) {
			
		}
	}
}
