package sftp.main.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import sftp.bean.SFTPBean;

public class SFTPMainDemo {

	public static void main(String[] args) {

		SFTPBean sftpBean = new SFTPBean();
	
		//connecting with sftp server
		boolean blResult = sftpBean.connect("192.168.56.101", 22, "root", "root01");

		if(blResult) {
			System.out.println("connected successfully");
			
			FileOutputStream fos;
			//creating zip of particular file
			try {
				fos = new FileOutputStream("C:\\Users\\GS-2145\\Desktop\\backup-files\\MyFile.zip");
				ZipOutputStream zos = new ZipOutputStream(fos);
				ZipEntry ze= new ZipEntry("file_example_WAV_1MG.wav");
				zos.putNextEntry(ze);
				FileInputStream in = new FileInputStream("C:\\Users\\GS-2145\\Desktop\\backup-files\\file_example_WAV_1MG.wav");
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			//uploading the created zip to remote location
			blResult = sftpBean.uploadFile("C:\\Users\\GS-2145\\Desktop\\backup-files\\MyFile.zip", "/upload/MyFile.zip");
			
			if(blResult) {
				System.out.println("downloaded/uploaded");
			}else {
				System.out.println("download/upload failed");
			}

		}

	}

}
